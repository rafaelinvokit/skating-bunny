# Skating bunny

A Pen created on CodePen.

Original URL: [https://codepen.io/Yakudoo/pen/poqazQo](https://codepen.io/Yakudoo/pen/poqazQo).

Skating bunny is a mini game (no score, no time, no leaderboard) just the cutest rabbit around in need of carrots. 
Move the mouse to orient your best friend and click to make him jump and grab some vegetables. made with three.js and custom shaders.